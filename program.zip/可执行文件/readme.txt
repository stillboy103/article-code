The folder contains programs that can be used for verification, all executable files can run in a Linux environment.
"case1.exe" refers to case A of Multiphase Sod problem and 100 cells are used.
"case2.exe" refers to Rouge test, 2500 cells are used and 17 parcels are placed at the specified location.
"case3.exe" refers to Interaction of shock wave and dense particle curtain, all the details are the same with the article.
"case4.exe" refers to Hele-Shaw problem, all the details are the same with the article.
"case5.exe" refers to Granular column impacted by shock wave, all the details are the same with the article.